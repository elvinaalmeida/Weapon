//
//  Weapons.hpp
//  ClassAssignment6
//
//  Created by Elvina Almeida on 4/24/19.
//  Copyright © 2019 Elvina Almeida. All rights reserved.
//
#include <stdio.h>
#pragma once

class Weapon
{
    
public:
    int damage;
    int durability;
    Weapon();
    Weapon(int damage, int durability);
    ~Weapon();
    
    
    int getDamage();
    int getDurability();
    
    virtual int calcDamage() = 0;
};
