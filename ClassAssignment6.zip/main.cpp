

#include <iostream>
#include <iomanip>
#include "Range.hpp"
#include "Melee.hpp"


using namespace std;

void displayWeaponStatus(Weapon& weapon)
{
    cout<<"Damage : "<<weapon.getDamage();
    cout<<endl<<"Durability : "<<weapon.getDurability();
    cout<<endl<<"Calculated Damage : "<<weapon.calcDamage() <<endl;
}

int main()
{

    Range range;
    Melee mele;
    
    Range rangeWeapon(20, 50, 200, 500);
    Melee meleeWeapon(40, 30, 2);
    
    cout << "Range stats:" << endl;
    displayWeaponStatus(rangeWeapon);
    cout << endl << "Melee stats:" << endl;;
    displayWeaponStatus(meleeWeapon);
    return 0;
}

