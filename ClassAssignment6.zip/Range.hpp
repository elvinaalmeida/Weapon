//
//  Range.hpp
//  ClassAssignment6
//
//  Created by Elvina Almeida on 4/24/19.
//  Copyright © 2019 Elvina Almeida. All rights reserved.
//


#define Range_hpp
#include "Weapon.hpp"

class Range:public Weapon
{
private:
    int range;
    int projectileDamage;
    
public:
    Range();
    Range(int damage, int durability, int range, int projectileDamage);
    ~Range();
    int getRange();
    int getProjectileDamage();
    void setRange(int range);
    void setProjectileDamage(int projectileDamage);
    int calcDamage();
};

