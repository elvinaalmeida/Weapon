//
//  Weapons.cpp
//  ClassAssignment6
//
//  Created by Elvina Almeida on 4/24/19.
//  Copyright © 2019 Elvina Almeida. All rights reserved.
//
#include "Weapon.hpp"

Weapon::Weapon()
{
    damage = 100;
    durability = 100;
}
Weapon::Weapon(int damage, int durability)
{
    this->damage = damage;
    this->durability = durability;
}

Weapon::~Weapon()
{
    
}

int Weapon::getDamage()
{
    return damage;
}

int Weapon::getDurability()
{
    return durability;
}

