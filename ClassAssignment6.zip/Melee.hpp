//
//  Melee.hpp
//  ClassAssignment6
//
//  Created by Elvina Almeida on 4/24/19.
//  Copyright © 2019 Elvina Almeida. All rights reserved.
//


#define Melee_hpp

#include <stdio.h>
#include "Weapon.hpp"

class Melee:public Weapon
{
    
private:
    int numOfHands;
public:
    Melee();
    Melee(int damage, int durability, int numOfHands);
    ~Melee();
    int getNumOfHands();
    void setNumOfHands();
    int calcDamage();
    
};
    


