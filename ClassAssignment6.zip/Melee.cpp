//
//  Melee.cpp
//  ClassAssignment6
//
//  Created by Elvina Almeida on 4/24/19.
//  Copyright © 2019 Elvina Almeida. All rights reserved.
//

#include "Melee.hpp"
#include "Weapon.hpp"

Melee::Melee():Weapon()
{
    numOfHands=0;
}

Melee::Melee(int damage, int durability, int numOfHands):Weapon(damage, durability)
{
    this->numOfHands = numOfHands;
}

Melee::~Melee()
{
    
}

// Accessors and Mutators
int Melee::getNumOfHands()
{
    return numOfHands;
}

void Melee::setNumOfHands()
{
    this->numOfHands = numOfHands;
}

// calcDamage calculates the base damage
// based on the number of Hands of the
// Melee Weapon
int Melee::calcDamage()
{
    if(numOfHands == 2)
    {
        //this->getDamage() * 2;
        return this->getDamage()*2;
    }
    else
    {
        return this->getDamage();
    }
}
