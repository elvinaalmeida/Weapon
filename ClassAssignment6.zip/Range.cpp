//
//  Range.cpp
//  ClassAssignment6
//
//  Created by Elvina Almeida on 4/24/19.
//  Copyright © 2019 Elvina Almeida. All rights reserved.
//

#include "Range.hpp"
#include "Weapon.hpp"

Range::Range():Weapon()
{
    this->range = 0;
    this->projectileDamage = 0;
}

Range::Range(int damage, int durability, int range, int projectileDamage):Weapon(damage, durability){
   
    this->range = range;
    this->projectileDamage = projectileDamage;
    
}

Range::~Range()
{
    
}

int Range::getRange()
{
    return range;
}

int Range::getProjectileDamage()
{
    
    return projectileDamage;
}

void Range::setRange(int range)
{
    
    this->range = range;
}

void Range::setProjectileDamage(int projectileDamage)
{
    this->projectileDamage = projectileDamage;
}

int Range::calcDamage()
{
    this->setProjectileDamage(this->getDamage()+this->getProjectileDamage());
    return getProjectileDamage();
}
